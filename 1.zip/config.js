// BOT TELE
module.exports = {
  BOT_TOKEN: "7293520306:AAEni0DlQMsSxSb147t_1APkc_fR_2NUUSA", // Token bot Telegram
  OWNER_ID: "7852320623", // ID pemilik bot
  allowedGroupIds: [-1002401306074, -1002361556670, -1002386380830, -1002415460020, -4514397992], // ID grup yang diizinkan
};