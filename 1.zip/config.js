// BOT TELE
module.exports = {
  BOT_TOKEN: "8045156974:AAGoLl6b_TNB5Q623pkW1bYCEoZiTQiff6o", // Token bot Telegram
  OWNER_ID: "7668731787", // ID pemilik bot
  allowedGroupIds: [-1002401306074, -1002361556670, -1002386380830, -1002415460020, -4514397992], // ID grup yang diizinkan
};